/*
 *rk_aiq_types_alsc_algo.h
 *
 *  Copyright (c) 2019 Rockchip Corporation
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 *
 */

#ifndef _RK_AIQ_TYPE_ABAYERTNR_ALGO_V23_H_
#define _RK_AIQ_TYPE_ABAYERTNR_ALGO_V23_H_
#include "abayertnrV23/rk_aiq_types_abayertnr_hw_v23.h"

RKAIQ_BEGIN_DECLARE

#define ABAYERTNR_USE_XML_FILE_V23 (1)
#define ABAYERTNR_USE_JSON_FILE_V23 (1)

RKAIQ_END_DECLARE

#endif

